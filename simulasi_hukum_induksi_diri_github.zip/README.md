# Simulasi Interaktif Hukum Induksi Diri

Website pembelajaran fisika interaktif untuk rangkaian RL (resistor–induktor).
Semua HTML, CSS, dan JavaScript sudah berada di dalam `index.html`, sehingga tidak
memerlukan instalasi, server backend, atau library eksternal.

## Cara menjalankan di laptop/HP

1. Ekstrak file ZIP.
2. Buka folder hasil ekstrak.
3. Buka `index.html` menggunakan browser (Chrome, Firefox, Edge, atau Safari).

## Cara memasang di GitHub Pages

1. Masuk ke https://github.com dan buat repository baru, misalnya `simulasi-induksi-diri`.
2. Pilih repository tersebut, lalu klik **Add file → Upload files**.
3. Unggah `index.html`, `README.md`, dan `.nojekyll` dari paket ini. Jika mengunggah dari ZIP, ekstrak dahulu.
4. Klik **Commit changes**.
5. Buka **Settings → Pages** di repository.
6. Pada **Build and deployment**, pilih **Deploy from a branch**.
7. Pilih branch `main` dan folder `/(root)`, lalu klik **Save**.
8. Tunggu proses deployment selesai. Tautan website akan ditampilkan di halaman Settings → Pages, biasanya berbentuk:
   `https://USERNAME.github.io/simulasi-induksi-diri/`
   Ganti `USERNAME` dengan nama pengguna GitHub Anda dan gunakan URL yang ditampilkan GitHub.

## Fitur

- Sakelar ON/OFF, Mulai, Jeda, Langkah, dan Reset.
- Pengaturan tegangan, hambatan, dan induktansi.
- Perhitungan arus, GGL induksi, konstanta waktu, dan energi magnetik.
- Tab Teori, Rumus, Grafik, dan Eksperimen.
- Tampilan responsif untuk layar ponsel dan laptop.

## Catatan ilmiah

Simulasi menggunakan model ideal rangkaian RL. Arus saat sakelar ditutup mengikuti
`I(t) = (V/R)(1 - e^(-t/tau))`, dengan `tau = L/R`. GGL induksi pada induktor
menentang perubahan arus sesuai hukum Lenz.
